from django.apps import AppConfig


class PromoappConfig(AppConfig):
    name = 'promoapp'
    verbose_name = "Promociones App"
