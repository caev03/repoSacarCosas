export interface Promo {
    id? : String;
    nombre? : String;
    descripcion? : String;
    imagen? : String;
    resumen? : String;
    precio? : String;
    fechaInicio? : String;
    fechaFin? : String;
    ciudad? : String;
    categoria? : String;
}