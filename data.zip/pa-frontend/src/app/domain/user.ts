export interface User {
    email? : String;
    password? : String;
}