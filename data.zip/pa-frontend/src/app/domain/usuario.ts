export interface Usuario {
    first_name? : String;
    last_name? : String;
    email? : String;
    foto? : String;
    direccion? : String;
    pais? : String;
    favoritas? : String;
}