import { Component, OnInit } from '@angular/core';
import { Validators, FormControl, FormGroup, FormBuilder} from '@angular/forms';
import { Router } from '@angular/router';

import { AuthService } from '../../services/auth.service';
import { Usuario } from '../../domain/usuario';

@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrls: ['./update-profile.component.scss'],
  providers: [ AuthService, ]
})
export class UpdateProfileComponent implements OnInit {

  updateform: FormGroup;
  messages: any[];
  user: Usuario;
  submitted = false;

  constructor(private fb: FormBuilder, private router: Router, private authService: AuthService) { }

  ngOnInit() {
    this.messages = [];
    this.getUserInfo();
    this.updateform = this.fb.group({
      'first_name':new FormControl('',Validators.compose([Validators.required])),
      'last_name':new FormControl('',Validators.compose([Validators.required])),
      'email': new FormControl('', Validators.compose([Validators.required, Validators.email])),
      'foto':new FormControl('',Validators.compose([Validators.required])),
      'password': new FormControl('', Validators.compose([Validators.required, Validators.minLength(8)]))
    });
  }

  onSubmit(value: string) {
    if ( this.updateform.valid ) {
        // this.authService.login(this.updateform.value);
    }
    this.submitted = true;
  }

  private getUserInfo(): void {
    console.log("a")
    this.authService.requestPersonalData().subscribe(data => this.user = data)
    console.log("b")
  }

}
