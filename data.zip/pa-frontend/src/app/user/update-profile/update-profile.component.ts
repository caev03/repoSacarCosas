import { Component, OnInit } from '@angular/core';
import { Validators, FormControl, FormGroup, FormBuilder} from '@angular/forms';
import { Router } from '@angular/router';

import { UserInfoService } from '../../services/get-user-info.service';

@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrls: ['./update-profile.component.scss'],
  providers: [UserInfoService,]
})
export class UpdateProfileComponent implements OnInit {

  updateform: FormGroup;
  messages: any[];
  user: {};

  constructor(private fb: FormBuilder, private router: Router, private userInfoService: UserInfoService) { }

  ngOnInit() {
    this.messages = [];
    this.updateform = this.fb.group({
      'email': new FormControl('', Validators.compose([Validators.required, Validators.email])),
      'password': new FormControl('', Validators.compose([Validators.required, Validators.minLength(8)]))
    });
  }

  private getUserInfo(): void {
    this.userInfoService.getInfo()
        .subscribe(user => this.user = user);
}

}
