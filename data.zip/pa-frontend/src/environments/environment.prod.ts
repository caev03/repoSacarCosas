export const environment = {
  production: true,
  api: 'https://miso4101.herokuapp.com/api'
};
